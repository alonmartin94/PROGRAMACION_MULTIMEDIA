package com.example.tiendaproductos.adapter

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toolbar
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.RecyclerView.ViewHolder
import com.bumptech.glide.Glide
import com.example.tiendaproductos.R
import com.example.tiendaproductos.SecondActivity
import com.example.tiendaproductos.model.productos

class productosAdapter(var lista: ArrayList<productos>, var carrito: ArrayList<productos>, var botonCarrito: Button, var context:Context): RecyclerView.Adapter<productosAdapter.MyHolder>() {


    //la clase anidada que va a representa el patron el template (filas)
    class MyHolder(item: View): ViewHolder(item){
        //crear tantas variables co0mo datos se van a mostrar en el item_recicler
        var imagen: ImageView
        var nombre: TextView
        var precio: TextView
        var boton: Button
        //metodo init (que siempre se ejecuta) inicializamos las variables
        init {
            imagen = item.findViewById(R.id.imagen_producto)
            nombre = item.findViewById(R.id.nombre_producto)
            precio = item.findViewById(R.id.precio_producto)
            boton = item.findViewById(R.id.btn_añadir_carrito)
        }
    }



    //funciones que definen como se pinta cada una de las filas del reciclerVIew

    //crea un template para "cada fila" -> lo deja creado
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyHolder {
        //el fichero xml con el aspecto de la fila
        val vista: View = LayoutInflater.from(context).inflate(R.layout.item_recycler, parent, false)
        //retorna la vista a traves de MyHolder
        return MyHolder(vista)
    }


    //representa cada dato en una posicion (de una lista) en su fila correspondiente
    override fun onBindViewHolder(holder: MyHolder, position: Int) {
        //este metodo se ejecuta una vez para cada fila

        //elemento o dato a representar -> en una posicion
        val producto = lista[position]
        holder.nombre.text = producto.nombre
        holder.precio.text = producto.precio.toString()
        Glide.with(context).load(producto.imagen).into(holder.imagen)
        holder.boton.setOnClickListener {
            añadirCarrito(position)

        }
        botonCarrito.setOnClickListener {
            val intent = Intent(context, SecondActivity::class.java)
            if(!carrito.equals(null)) {
                intent.putExtra("carro", carrito)
                context.startActivity(intent)
            } else{

            }
        }


        TODO("Not yet implemented")
    }


    //cuantas filas tengo que pintar
    override fun getItemCount(): Int {
        return lista.size

    }

    fun añadirCarrito(position: Int){
        carrito.add(lista[position])
    }

    fun addproducto(producto: productos) {
        this.lista.add(producto)
        notifyItemInserted(lista.size-1)
    }


    fun filtrarLista(categoria: String) {
        if(categoria.equals("Todos")){
            this.lista
        } else {
            this.lista.filter {
                it.categoria.equals(categoria,true)
            } as ArrayList<productos>
        }
        notifyDataSetChanged()
    }

    fun devolverCarro(): ArrayList<productos> {
        return carrito
    }


}