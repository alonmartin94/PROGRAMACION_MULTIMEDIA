package com.example.tiendaproductos

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.View.OnClickListener
import com.example.tiendaproductos.databinding.ActivitySecondBinding
import com.google.android.material.snackbar.Snackbar

class SecondActivity : AppCompatActivity() {

    //hacer siempre al crear una pantalla nueva
    private lateinit var binding: ActivitySecondBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //hacer siempre al crear una pantalla nueva
        binding = ActivitySecondBinding.inflate(layoutInflater)
        //activar la visualizacion del activitySecond
        setContentView(binding.root)
        //activar la visualizacion del menu
        setSupportActionBar(binding.toolbar)

    }
    //funcion para manejar eventos de click
    fun onClick(v: View?) {
    }

    //funcion para cargar el menu en la panatalla
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_activity_second, menu)
        return true
    }

    //funcion para la seleccion del item del menu
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.action_confirmarCompra -> {
                //codigo confirmar compra

                //snackbar confirmar compra
                Snackbar.make(
                    binding.root, "Enhorabuena, compra por valor de /**/ realizada",
                    Snackbar.LENGTH_SHORT
                ).show()
            }
            R.id.action_vaciarCarrito -> {
                //codigo vaciar carrito

                //snackbar vaciar carrito
                Snackbar.make(
                    binding.root, "carrito vaciado",
                    Snackbar.LENGTH_SHORT
                ).show()
            }
        }
        return true
    }


}