package com.example.tiendaproductos.model

import java.io.Serializable

class productos (var nombre: String, var imagen: String, var precio: Int, var categoria:String):Serializable {
    //funcion para obtener la posicion para el metodo (onBindViewHolder)
    /*operator fun get(position: Int): Any {

    }*/

    }

