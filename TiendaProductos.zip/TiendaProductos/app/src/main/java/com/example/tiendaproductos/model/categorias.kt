package com.example.tiendaproductos.model

class categorias( )