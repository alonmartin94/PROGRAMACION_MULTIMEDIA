package com.example.tiendaproductos

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.View.OnClickListener
import android.widget.AdapterView
import android.widget.Button
import androidx.recyclerview.widget.LinearLayoutManager
import com.android.volley.Request
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.example.tiendaproductos.adapter.productosAdapter
import com.example.tiendaproductos.databinding.ActivityMainBinding
import com.example.tiendaproductos.model.productos
import com.google.android.material.navigation.NavigationBarView
import com.google.android.material.snackbar.Snackbar
import org.json.JSONArray

class MainActivity : AppCompatActivity() {

    //hacer siempre al comenzar proyecto
    private lateinit var binding: ActivityMainBinding
    private lateinit var productosAdapter: productosAdapter
    private lateinit var lista: ArrayList<productos>
    private lateinit var carrito: ArrayList<productos>


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //hacer siempre al comenzar proyecto
        binding = ActivityMainBinding.inflate(layoutInflater)
        //inicializo arrays
        lista = ArrayList()
        carrito = ArrayList()
        rellenarLista()
        //PARTE GRAFICA (binding)
        //activar la visualizacion del activityMain
        setContentView(binding.root)
        // Encuentra el botón directamente en la actividad
        val actionCarritoButton = findViewById<Button>(R.id.action_carrito)

        // Verifica que actionCarritoButton no sea nulo antes de pasarlo al adaptador
        if (actionCarritoButton != null) {
            productosAdapter = productosAdapter(lista, carrito, actionCarritoButton, this)
        } else {
            // Manejar el caso en el que no se encuentra el botón
            // Puedes mostrar un mensaje de error, log, etc.
        }

        //inicializo el productAdapter
        productosAdapter = productosAdapter(lista, carrito, binding.toolbar.findViewById(R.id.action_carrito), this)
        //para tener acceso al recycler (parte grafica -> XML)
        binding.recyclerProductos.adapter = productosAdapter
        binding.recyclerProductos.layoutManager =
            LinearLayoutManager(applicationContext, LinearLayoutManager.VERTICAL, false)

        binding.spinnerCategorias.onItemSelectedListener = object : NavigationBarView.OnItemSelectedListener,
                AdapterView.OnItemSelectedListener {
                override fun onItemSelected(
                    parent: AdapterView<*>?,
                    view: View?,
                    position: Int,
                    id: Long
                ) {
                    val seleccionado = parent!!.adapter.getItem(position).toString()
                    productosAdapter.filtrarLista(seleccionado)
                }

                override fun onNothingSelected(parent: AdapterView<*>?) {

                }

                override fun onNavigationItemSelected(item: MenuItem): Boolean {
                    TODO("Not yet implemented")
                }

            }

    }

    //funcion para manejar eventos de click


    //funcion para cargar el menu en la panatalla
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_activity_main, menu)
        return true
    }

    //funcion para la seleccion del item del menu
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.action_carrito -> {
                //devolver productos almacenados en el carrito
                carrito = productosAdapter.devolverCarro()
                //activar la pantalla secondaActivity
                val intent: Intent = Intent(applicationContext, SecondActivity::class.java)
                intent.putExtra("carrito", carrito)
                startActivity(intent)
            }
        }
        return true
    }

        //funcion para rellenar con los datos de la api
        fun rellenarLista() {
            val peticion: JsonObjectRequest =
                JsonObjectRequest(Request.Method.GET, "https://dummyjson.com/products", null, {
                    val products: JSONArray = it.getJSONArray("products")
                    for (i in 0 until products.length()) {
                        val product = products.getJSONObject(i)
                        productosAdapter.addproducto(
                            productos(
                                product.getString("title"),
                                product.getString("thumbnail"),
                                product.getInt("price"),
                                product.getString("category")
                            )
                        )
                    }


                }, {
                    Snackbar.make(binding.root, "Error en la conexión", Snackbar.LENGTH_SHORT)
                        .show()
                })
            Volley.newRequestQueue(this).add(peticion)
        }


}